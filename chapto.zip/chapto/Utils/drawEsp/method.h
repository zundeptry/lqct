#include <UIKit/UIKit.h>
#import <vector>
#import <string>
#import "../MethodObfuscation.h"
#import "../../Security/oxorany/oxorany_include.h"

#define IM_PI 3.14159265358979323846f
#define RAD2DEG(x) ((float)(x) * (float)(180.f / IM_PI))
#define DEG2RAD(x) ((float)(x) * (float)(IM_PI / 180.f))
#define kWidth [UIScreen mainScreen].bounds.size.width
#define kHeight [UIScreen mainScreen].bounds.size.height

using namespace std;








